
import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Sparkles, DollarSign } from "lucide-react";
import { motion } from "framer-motion";

export default function AuraCatHome() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-[#1f103f] to-[#0d081c] text-white font-sans">
      <section className="text-center py-20 px-4">
        <motion.h1
          className="text-5xl md:text-7xl font-bold text-yellow-400"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          AuraCat
        </motion.h1>
        <p className="mt-4 text-xl md:text-2xl text-gray-300">
          Pengendali segala Meme Coin dengan kekuatan aura mistis.
        </p>
        <motion.img
          src="/auracat-logo.png"
          alt="AuraCat Logo"
          className="mx-auto mt-10 w-60 md:w-80"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 1 }}
        />
        <div className="mt-10">
          <Button className="bg-yellow-400 text-black text-lg px-6 py-3 rounded-2xl shadow-lg hover:bg-yellow-300">
            Beli Sekarang
          </Button>
        </div>
      </section>

      <section className="px-6 py-16 grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
        <Card className="bg-[#2a1e4d] border-0">
          <CardContent className="p-6">
            <Sparkles className="text-purple-300 w-10 h-10 mb-4" />
            <h2 className="text-2xl font-semibold mb-2 text-yellow-300">Aura Mistis</h2>
            <p className="text-gray-300">
              Setiap transaksi dilindungi oleh kekuatan aura kucing ilahi. Aman dan ajaib.
            </p>
          </CardContent>
        </Card>
        <Card className="bg-[#2a1e4d] border-0">
          <CardContent className="p-6">
            <DollarSign className="text-green-300 w-10 h-10 mb-4" />
            <h2 className="text-2xl font-semibold mb-2 text-yellow-300">Memeconomy</h2>
            <p className="text-gray-300">
              AuraCat bukan sekadar coin. Ini adalah kekuatan yang mengatur pasar meme crypto.
            </p>
          </CardContent>
        </Card>
        <Card className="bg-[#2a1e4d] border-0">
          <CardContent className="p-6">
            <img src="/cat-crown.png" alt="Cat King" className="w-10 h-10 mb-4" />
            <h2 className="text-2xl font-semibold mb-2 text-yellow-300">Raja Meme</h2>
            <p className="text-gray-300">
              Dengan gaya kartun 3D dan jiwa penguasa, AuraCat adalah rajanya semua meme coin.
            </p>
          </CardContent>
        </Card>
      </section>
    </main>
  );
}
